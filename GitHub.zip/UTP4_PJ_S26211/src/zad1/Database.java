/**
 * @author Politowicz Jakub S26211
 **/

package zad1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.List;

public class Database {
    private String url;
    private TravelData travelData;

    public Database(String url, TravelData travelData) {
        this.url = url;
        this.travelData = travelData;
    }

    public void create() {
        try (Connection connection = DriverManager.getConnection(url)) {
            try (Statement statement = connection.createStatement()) {
                statement.executeUpdate("CREATE TABLE IF NOT EXISTS offers (" +
                        "country TEXT, departure_date DATE, return_date DATE, " +
                        "place TEXT, price DECIMAL, currency TEXT, language TEXT)");
                List<String> offers = travelData.getOffersDescriptionsList("en_US", "yyyy-MM-dd");
                for (String offer : offers) {
                    String[] parts = offer.split(" ");
                    String query = String.format("INSERT INTO offers VALUES ('%s', '%s', '%s', '%s', %s, '%s', '%s')",
                            parts[0], parts[1], parts[2], parts[3], parts[4].replace(",", "."), parts[5], parts[6]);
                    statement.executeUpdate(query);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void showGui() {
        JFrame frame = new JFrame("Travel Offers");
        JTable table = new JTable();
        DefaultTableModel model = new DefaultTableModel();
        table.setModel(model);

        JComboBox<String> languageComboBox = new JComboBox<>(new String[]{"pl_PL", "en_GB"});
        JButton refreshButton = new JButton("Refresh");

        refreshButton.addActionListener(e -> {
            String selectedLanguage = (String) languageComboBox.getSelectedItem();
            List<String> offers = travelData.getOffersDescriptionsList(selectedLanguage, "yyyy-MM-dd");

            model.setColumnCount(0);
            model.setRowCount(0);

            model.addColumn("Language");
            model.addColumn("Country");
            model.addColumn("Departure Date");
            model.addColumn("Return Date");
            model.addColumn("Place");
            model.addColumn("Price");
            model.addColumn("Currency");

            for (String offer : offers) {
                String[] parts = offer.split(" ");
                model.addRow(parts);
            }
        });

        JPanel controlPanel = new JPanel();
        controlPanel.add(new JLabel("Language:"));
        controlPanel.add(languageComboBox);
        controlPanel.add(refreshButton);

        frame.add(controlPanel, "North");
        frame.add(new JScrollPane(table), "Center");

        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}