/**
 * @author Politowicz Jakub S26211
 **/

package zad1;

import java.io.*;
import java.text.*;
import java.util.*;

public class TravelData {
    private File dataDir;

    public TravelData(File dataDir) {
        this.dataDir = dataDir;
    }

    public List<String> getOffersDescriptionsList(String loc, String dateFormat) {
        List<String> offersDescriptions = new ArrayList<>();

        Locale locale = new Locale(loc);
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, locale);

        File[] files = dataDir.listFiles();

        if (files != null) {
            for (File file : files) {
                try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] parts = line.split("\t");
                        String country = parts[1];
                        String startDate = sdf.format(Objects.requireNonNull(new SimpleDateFormat("yyyy-MM-dd").parse(parts[2])));
                        String endDate = sdf.format(Objects.requireNonNull(new SimpleDateFormat("yyyy-MM-dd").parse(parts[3])));
                        String place = parts[4];
                        String price = parts[5];
                        String currency = parts[6];

                        String description = String.format("%s %s %s %s %s %s %s",
                                locale.getDisplayName(locale), country, startDate, endDate, place, price, currency);
                        offersDescriptions.add(description);
                    }
                } catch (IOException | ParseException e) {
                    e.printStackTrace();
                }
            }
        }

        return offersDescriptions;
    }
}