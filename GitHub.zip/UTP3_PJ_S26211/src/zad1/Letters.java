/**
 *
 *  @author Politowicz Jakub S26211
 *
 */

package zad1;

public class Letters implements Runnable {
    private final String letters;
    private final Thread[] threads;

    public Letters(String letters) {
        this.letters = letters;
        this.threads = new Thread[letters.length()];
        initializeThreads();
    }

    private void initializeThreads() {
        for (int i = 0; i < letters.length(); i++) {
            char letter = letters.charAt(i);
            threads[i] = new Thread(this, "Thread " + letter);
        }
    }

    public Thread[] getThreads() {
        return threads;
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < 5; i++) {
                letters.chars().forEach(ch -> System.out.print((char) ch));
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
