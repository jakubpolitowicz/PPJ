/**
 *
 *  @author Politowicz Jakub S26211
 *
 */

package zad3;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;

public class Task implements Callable<String> {

    private final String input;
    private final int repetitions;
    private volatile Future<?> future;
    private volatile String result;

    public Task(String input, int repetitions) {
        this.input = input;
        this.repetitions = repetitions;
    }

    public void setFuture(Future<?> future) {
        this.future = future;
    }

    public void cancel() {
        if (future != null) {
            future.cancel(true);
        }
    }

    public String getResult() {
        return result;
    }

    @Override
    public String call() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < repetitions; i++) {
            if (Thread.currentThread().isInterrupted()) {
                result = "Task was cancelled";
                return result;
            }
            builder.append(input);
        }
        result = builder.toString();
        return result;
    }

    @Override
    public String toString() {
        return "Task: " + input + ", Repetitions: " + repetitions;
    }
}