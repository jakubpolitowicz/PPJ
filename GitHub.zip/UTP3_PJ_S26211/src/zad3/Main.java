/**
 *
 *  @author Politowicz Jakub S26211
 *
 */

package zad3;

import javax.swing.*;

public class Main {
	public static void main(String[] args) {
        SwingUtilities.invokeLater(SwingTaskManager::new);
    }
}