/**
 *
 * @author Politowicz Jakub S26211
 *
 */

package zad4;

public class Author implements Runnable {
	
	 private String[] messages;

	    public Author(String[] messages) {
	        this.messages = messages;
	    }

	    public String[] getMessages() {
	        return messages;
	    }

	    @Override
	    public void run() {
	        try {
	            for (String message : messages) {
	                Thread.sleep(1000);
	            }
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt();
	        }
	    }
	}