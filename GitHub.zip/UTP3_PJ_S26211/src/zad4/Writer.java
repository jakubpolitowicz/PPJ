/**
 *
 * @author Politowicz Jakub S26211
 *
 */

package zad4;

public class Writer implements Runnable {
    private Author author;

    public Writer(Author author) {
        this.author = author;
    }

    @Override
    public void run() {
        String[] messages = author.getMessages();
        for (String message : messages) {
            System.out.println("Writer received: " + message);
        }
    }
}