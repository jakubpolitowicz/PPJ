/**
 *
 *  @author Politowicz Jakub S26211
 *
 */

package zad2;

public enum TaskState {
    CREATED,
    RUNNING,
    ABORTED,
    READY
}