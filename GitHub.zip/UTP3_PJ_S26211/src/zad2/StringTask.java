/**
 *
 *  @author Politowicz Jakub S26211
 *
 */

package zad2;

public class StringTask implements Runnable {
    private final String input;
    private final int repetitions;
    private volatile String result;
    private volatile TaskState state;

    public StringTask(String input, int repetitions) {
        this.input = input;
        this.repetitions = repetitions;
        this.state = TaskState.CREATED;
    }

    public String getResult() {
        return result;
    }

    public TaskState getState() {
        return state;
    }

    public void start() {
        Thread thread = new Thread(this);
        thread.start();
    }

    public void abort() {
        if (state == TaskState.RUNNING) {
            state = TaskState.ABORTED;
        }
    }

    public boolean isDone() {
        return state == TaskState.READY || state == TaskState.ABORTED;
    }

    @Override
    public void run() {
        state = TaskState.RUNNING;
        String concatenated = "";
        try {
            for (int i = 0; i < repetitions; i++) {
                if (Thread.interrupted()) {
                    throw new InterruptedException();
                }
                concatenated += input;
            }
            result = concatenated;
            state = TaskState.READY;
        } catch (InterruptedException e) {
            state = TaskState.ABORTED;
        }
    }
}