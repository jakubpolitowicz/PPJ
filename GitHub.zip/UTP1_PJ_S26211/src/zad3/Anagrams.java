/**
 *
 *  @author Politowicz Jakub S26211
 *
 */

package zad3;


import java.io.*;
import java.util.*;

public class Anagrams {
    private final Map<String, List<String>> anagramMap;

    public Anagrams(String filePath) {
        this.anagramMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = br.readLine()) != null) {
                String sortedWord = sortString(line);

                if (!anagramMap.containsKey(sortedWord)) {
                    anagramMap.put(sortedWord, new ArrayList<>());
                }

                anagramMap.get(sortedWord).add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<List<String>> getSortedByAnQty() {
        List<List<String>> sortedAnagrams = new ArrayList<>(anagramMap.values());

        sortedAnagrams.sort((list1, list2) -> {
            int size1 = list1.size();
            int size2 = list2.size();

            if (size1 == size2) {
                return list1.get(0).compareTo(list2.get(0));
            }

            return Integer.compare(size2, size1);
        });

        return sortedAnagrams;
    }

    public String getAnagramsFor(String word) {
        String sortedWord = sortString(word);

        if (!anagramMap.containsKey(sortedWord)) {
            return word + ": []";
        }

        List<String> anagrams = anagramMap.get(sortedWord);
        StringBuilder sb = new StringBuilder(word + ": [");

        for (int i = 0; i < anagrams.size(); i++) {
            sb.append(anagrams.get(i));

            if (i != anagrams.size() - 1) {
                sb.append(", ");
            }
        }

        sb.append("]");

        return sb.toString();
    }

    private static String sortString(String str) {
        char[] chars = str.toCharArray();
        Arrays.sort(chars);
        return new String(chars);
    }
}